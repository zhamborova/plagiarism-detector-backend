import ASTNode from './ASTNode'

/**
 * root of the Expr subhierarchy
 */
abstract class Expr extends ASTNode {
   
}

export default Expr