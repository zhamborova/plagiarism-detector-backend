
/**
 * Interface representing TypeCheckErrors of AST nodes
 */
export default interface ITypeCheckError{
    toString(): String
}