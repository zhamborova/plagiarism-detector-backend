import ASTNode from './ASTNode'

/**
 * root of the statement subhierarchy.  
 */
abstract class Stmt extends ASTNode {

}

export default Stmt